# -*- encoding: utf-8 -*-
###########################################################################
#
#    Copyright (C) 2016 - Today Turkesh Patel. <http://turkeshpatel.odoo.com>
#
#    @author Turkesh Patel <turkesh4friends@gmail.com>
###########################################################################

{
    'name': 'Project Task Start Stop',
    'version': '1.0',
    'author' : 'Turkesh Patel',
    'website' : 'http://turkehpatel.odoo.com',
    'summary': """Project Task Start Stop functionality.""",
    'description': """Project Task Start Stop improvements to simplify project task usability""",
    'depends': ['project', 'hr_timesheet'],
    'category': 'Project Management',
    'data': [
        'views/project_view.xml',
        'views/project_template.xml',
    ],
    'images': [
        'static/description/tasks_start_stop_kanban_cover_almightycs.png',
    ],
    'installable': True,
    'auto_install': False,
    'price': 35,
    'currency': 'EUR',
}
